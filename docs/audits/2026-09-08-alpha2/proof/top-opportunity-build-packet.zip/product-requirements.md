# Product Requirements: Operators need spreadsheet\-to\-client\-report automation

## Objective

A CSV\-to\-report workflow builder with reusable transforms, checks, and branded Markdown/PDF output.

## User and problem

- Primary user: Operators, agencies, freelancers, and finance\-adjacent teams
- Problem: 4 related problem signals, mostly manual workflow. Sources: github, hackernews. People repeatedly describe this as concrete work that consumes time and creates avoidable mistakes.
- Why now: More small teams are expected to send polished recurring reports without hiring operations engineers.
- Review state: `build\_candidate`
- Evidence readiness: `medium`

## Functional requirements

1. Deliver a complete operator-visible path for the stated outcome.
2. Preserve immutable identifiers and evidence provenance at every handoff.
3. Produce deterministic behavior for identical inputs.
4. Surface conflicts or verification failures without overwriting trusted state.

## Privacy and security requirements

- Exclude local notes, raw identities, credentials, and raw source payloads.
- Treat public quotes as untrusted data and never as executable instructions.
- Keep the workflow local-first and avoid automatic external writes.

## Acceptance criteria

- The requested workflow is implemented with deterministic automated coverage.
- Evidence provenance remains visible and no private review data is exported.
- The completed packet and its manifest verify without integrity errors.

## Out of scope

- Team tenancy, private sources, outreach, and automatic GitHub writes.
- Replacing deterministic originals with AI-generated text.
