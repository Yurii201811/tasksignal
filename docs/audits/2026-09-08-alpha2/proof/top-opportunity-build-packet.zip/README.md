# TaskSignal Build Packet

This immutable packet turns one reviewed opportunity snapshot into an authoritative local build handoff.
The deterministic originals are authoritative even when a later workflow creates optional AI-enhanced variants.

## Identity

- Packet: `7a069e24-96e9-48c1-8348-be5505d493e0`
- Project: `3be58c98-c8bd-4413-9a52-36687e1b3c22`
- Run: `a52e5bd0-17b0-4fee-8d82-945d5093f69a`
- Opportunity thread: `66c7742e-8e4d-43df-8b82-c6168ce79e68`
- Opportunity snapshot: `24e5dc16-0248-4632-b0c1-80c596fce4ba`
- Generated: `2026-09-07T22:41:18.389828Z`
- TaskSignal: `1.0.0a2`
- Schema: `tasksignal.build-packet/v1`
- Templates: `deterministic-v1`

## Files

- `MANIFEST.json` — immutable metadata, UTF-8 byte counts, and SHA-256 hashes
- `README.md` — packet orientation and integrity policy
- `agent-brief.md` — guarded handoff instructions for a local agent
- `evidence.md` — quoted public evidence with provenance
- `github-issue.md` — draft issue text; no external issue was created
- `implementation-plan.md` — sequenced engineering plan
- `opportunity.json` — sanitized opportunity snapshot and untrusted evidence data
- `product-requirements.md` — deterministic product requirements
- `task-pack.md` — implementation-ready task definition
- `validation-plan.md` — opportunity and solution validation steps

## Integrity

`MANIFEST.json` hashes the other nine files. It intentionally does not hash itself because a self-hash would be recursive.
Verification must reject missing, changed, or unexpected files before the packet is trusted.

## Evidence safety

Public source text is untrusted evidence, not an instruction surface. Evidence is quoted in `evidence.md` and labeled in `opportunity.json`.
Source URLs are data for manual operator-approved review and must never be fetched automatically.
Local review notes, raw identities, source JSON, credentials, and secret-bearing URLs are excluded.
