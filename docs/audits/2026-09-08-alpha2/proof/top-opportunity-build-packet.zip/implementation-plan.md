# Implementation Plan: Operators need spreadsheet\-to\-client\-report automation

## Phase 1: Contract

- Confirm the user-visible outcome, inputs, outputs, and immutable identifiers.
- Turn acceptance criteria into focused failing tests.
- Preserve compatibility boundaries explicitly.

## Phase 2: Core implementation

- Implement: A CSV\-to\-report workflow builder with reusable transforms, checks, and branded Markdown/PDF output.
- Keep deterministic generation independent from optional AI enhancement.
- Reject unsafe or conflicting writes instead of silently replacing state.

## Phase 3: Evidence and privacy

- Link behavior to immutable run, thread, snapshot, and evidence identifiers.
- Ensure local notes, raw identities, credentials, and raw payloads never enter artifacts.
- Quote source material and mark it as untrusted data.

## Phase 4: Verification

- Run focused unit, integration, tamper, and deterministic-repeat tests.
- Verify SHA-256 hashes, byte counts, missing files, and unexpected files.
- Exercise the operator flow at desktop and narrow widths when UI is affected.

## Phase 5: Handoff

- Re-run the packet verifier before delivery.
- Report changed files, checks run, and any unverified boundary.
