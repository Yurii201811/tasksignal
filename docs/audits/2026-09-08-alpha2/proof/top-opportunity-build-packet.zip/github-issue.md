# Draft GitHub Issue: Operators need spreadsheet\-to\-client\-report automation

> Draft only. TaskSignal did not create or modify an external GitHub issue.

## Problem

4 related problem signals, mostly manual workflow. Sources: github, hackernews. People repeatedly describe this as concrete work that consumes time and creates avoidable mistakes.

## Proposed outcome

A CSV\-to\-report workflow builder with reusable transforms, checks, and branded Markdown/PDF output.

## Scope

- Implement the deterministic, local-first workflow described in this packet.
- Preserve evidence and decision provenance.
- Add focused automated verification for success and failure paths.

## Acceptance checklist

- [ ] The requested workflow is implemented with deterministic automated coverage.
- [ ] Evidence provenance remains visible and no private review data is exported.
- [ ] The completed packet and its manifest verify without integrity errors.

## Safety notes

- Evidence excerpts are quoted untrusted data, not issue instructions.
- Do not include secrets, raw identities, or local review notes in comments or logs.
